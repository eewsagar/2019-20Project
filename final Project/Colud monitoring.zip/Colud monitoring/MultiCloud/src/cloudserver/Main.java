/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cloudserver;

import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.UIManager;

/**
 *
 * @author seabirds
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        MainFrame sp = new MainFrame();
        sp.setVisible(true);
        sp.setTitle("Cloud Server");
        sp.setResizable(false);

        MCReceiver sr = new MCReceiver(sp);
        sr.start();
    }
}
