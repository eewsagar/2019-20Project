package com.kmeans.process;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;
import org.jfree.ui.RefineryUtilities;

/**
 * Swing-based program for testing the versions of K-Means on randomly generated
 * data.
 */
public class KMeansFrame extends JFrame
        implements ActionListener,
        KMeansListener {

    JPanel contentPane;
    BorderLayout borderLayout1 = new BorderLayout();
    JScrollPane mMessageAreaSP = new JScrollPane();
    JTextArea mMessageArea = new JTextArea();
    JButton mRunButton = new JButton();
    JButton mResButton = new JButton();
    JPanel mTopPanel = new JPanel();
    JLabel mImplementationLabel = new JLabel();
    JTextField mRandomSeedTF = new JTextField();
    JLabel mRandomSeedLabel = new JLabel();
    JTextField mClusterCountTF = new JTextField();
    JLabel mClusterCountLabel = new JLabel();
    JTextField mCoordCountTF = new JTextField();
    JLabel mCountLabel = new JLabel();
    JComboBox mImplementationCB = new JComboBox();
    GridBagLayout gridBagLayout1 = new GridBagLayout();
    JLabel mThreadCountLabel = new JLabel();
    JTextField mThreadCountTF = new JTextField();

    private boolean mRunning;
    private KMeans mKMeans;

    private static final String BASIC_KMEANS = "Dos";
    private static final String p2C = "K-Means p2C Clustering";
    private static final String CONCURRENT_KMEANS = "ping of Death";
    public static String ipadd = "", per = "";
    public static int d = 0, n = 0, chk = 0;
    private static String pre = "", dper = "";
    private static String filePath = "";

    public KMeansFrame(int n) {

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(borderLayout1);
        setSize(new Dimension(620, 600));
        setTitle("KMeans");
        mMessageArea.setText("");
        mRunButton.setText("Run KMeans");
        mRunButton.addActionListener(this);

        mResButton.setText("Result");
        mResButton.addActionListener(this);
        mImplementationLabel.setText("KMeans Implementation:");
        mImplementationCB.addActionListener(this);
        mRandomSeedTF.setText("123");
        mRandomSeedTF.setColumns(10);
        //  mRandomSeedLabel.setText("Random Seed:");
        mClusterCountTF.setText("3");
        mClusterCountTF.setColumns(10);
        mClusterCountLabel.setText("Number of Clusters (K):");
        //number of records

        mCoordCountTF.setText(String.valueOf(n));
        mCoordCountTF.setColumns(10);
        mCountLabel.setText("Number of Coordinates (N):");
        mThreadCountLabel.setVisible(false);
        mThreadCountLabel.setText("Number of Threads:");
        mThreadCountTF.setVisible(false);
        // Initialize the thread count textfield with the
        // number of available processors.
        mThreadCountTF.setText(String.valueOf(Runtime.getRuntime().availableProcessors()));
        mThreadCountTF.setColumns(10);
        mTopPanel.setLayout(gridBagLayout1);
        contentPane.add(mMessageAreaSP, java.awt.BorderLayout.CENTER);
        contentPane.add(mTopPanel, java.awt.BorderLayout.NORTH);
        mMessageAreaSP.getViewport().add(mMessageArea);
        mTopPanel.add(mCountLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
                new Insets(10, 10, 5, 0), 0, 0));
        mTopPanel.add(mCoordCountTF,
                new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets(10, 0, 5, 10), 0, 0));
        mTopPanel.add(mClusterCountLabel,
                new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets(0, 10, 5, 0), 0, 0));
        mTopPanel.add(mClusterCountTF,
                new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets(0, 0, 5, 10), 0, 0));
        mTopPanel.add(mRandomSeedLabel,
                new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets(0, 10, 5, 0), 0, 0));
        mTopPanel.add(mRandomSeedTF,
                new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets(0, 0, 5, 10), 0, 0));
        mTopPanel.add(mImplementationLabel,
                new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets(0, 10, 5, 0), 0, 0));
        mTopPanel.add(mImplementationCB,
                new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER,
                        GridBagConstraints.HORIZONTAL,
                        new Insets(0, 2, 5, 10), 0, 0));
        mTopPanel.add(mThreadCountLabel,
                new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0, GridBagConstraints.EAST,
                        GridBagConstraints.NONE,
                        new Insets(0, 10, 5, 0), 0, 0));
        mTopPanel.add(mThreadCountTF,
                new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
                        GridBagConstraints.NONE,
                        new Insets(0, 2, 5, 10), 0, 0));
        mTopPanel.add(mRunButton, new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 5, 10), 0, 0));
        mTopPanel.add(mResButton, new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 50, 10), 0, 0));

        //
        mRandomSeedLabel.setVisible(false);
        mRandomSeedTF.setVisible(false);
        mImplementationCB.addItem(BASIC_KMEANS);

        mImplementationCB.addItem(CONCURRENT_KMEANS);
    }

    /**
     * Method for validating entries typed into text fields.
     */
    private static long getEnteredValue(JTextField tf, long min, long max) {
        long value = 0L;
        String s = tf.getText().trim();
        if (s.length() == 0) {
            throw new RuntimeException("blank entry");
        }
        try {
            value = Long.parseLong(s);
            if (value < min || value > max) {
                throw new RuntimeException("not in range [" + min + " - " + max + "]");
            }
        } catch (NumberFormatException nfe) {
            throw new RuntimeException("invalid number");
        }
        return value;
    }

    /**
     * Generates the coordinates to be clustered.
     *
     * @param coordCount the number of coordinates.
     * @param dimensions the length of the coordinates.
     * @param clusterCount the number of clusters in the distribution.
     * @param randomSeed the seed used by the random number generator.
     * @return
     */
    private static double[][] generateCoordinates(
            int coordCount, int dimensions, int clusterCount, long randomSeed)
            throws InsufficientMemoryException {

        // Explicit garbage collection to reduce the likelihood of 
        // having insufficient memory.
        System.gc();

        long memRequired = 8L * (long) dimensions * (long) (coordCount + clusterCount);
        if (Runtime.getRuntime().freeMemory() < memRequired) {
            throw new InsufficientMemoryException();
        }

        double[][] coordinates = new double[coordCount][dimensions];
        double[][] exemplars = new double[clusterCount][dimensions];

        Random random = new Random(randomSeed);
        for (int i = 0; i < clusterCount; i++) {
            for (int j = 0; j < dimensions; j++) {
                exemplars[i][j] = 100.0 * random.nextDouble();
            }
        }

        for (int i = 0; i < coordCount; i++) {
            int cluster = random.nextInt(clusterCount);
            double[] exemplar = exemplars[cluster];
            double[] coord = coordinates[i];
            for (int j = 0; j < dimensions; j++) {
                coord[j] = exemplar[j] + 50 * random.nextGaussian();
            }
        }

        return coordinates;
    }

    public synchronized void actionPerformed(ActionEvent e) {

        if (e.getSource() == mRunButton && !mRunning) {

            // Ensure entered parameters make sense.
            try {

                int coordCount = (int) getEnteredValue(mCoordCountTF,
                        1L, (long) Integer.MAX_VALUE);
                int clusterCount = (int) getEnteredValue(mClusterCountTF,
                        1L, (long) (coordCount - 1));
                long randomSeed = getEnteredValue(mRandomSeedTF,
                        Long.MIN_VALUE, Long.MAX_VALUE);

                double[][] coordinates = generateCoordinates(coordCount, 100, clusterCount, randomSeed);

                String implementation = (String) mImplementationCB.getSelectedItem();
                if (implementation == BASIC_KMEANS) {
                    int val = dos(0);
                    chk = 1;
                    //  double nor=100.0-(val/100);
                    mKMeans = new P2C(coordinates, clusterCount, 500, randomSeed);

                    pre = "Dos Cluster:" + (val / 100) + "%\n";

                } else if (implementation == CONCURRENT_KMEANS) {
                    try {
                        chk = 0;

                        mKMeans = new P2C(coordinates, clusterCount, 500, randomSeed);
                        Ping(6000, 0);
                    } catch (RuntimeException rte2) {
                        JOptionPane.showMessageDialog(this,
                                "The thread count entry is invalid (" + rte2.getMessage()
                                + ").\nPlease enter a thread count in the range [1 - 20].",
                                "Invalid Entry", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                if (mKMeans != null) {
                    // Force gc, so resources taken up by a previous run that haven't
                    // been freed yet, will not affect this test.
                    System.gc();

                    mMessageArea.setText("");
                    mKMeans.addKMeansListener(this);
                    mRunButton.setEnabled(false);
                    new Thread(mKMeans).start();
                    mRunning = true;
                }

            } catch (InsufficientMemoryException ime) {

                displayInsufficientMemoryDialog();

            } catch (RuntimeException rte) {

                JOptionPane.showMessageDialog(this,
                        "One or more entries are invalid (" + rte.getMessage()
                        + ").\nPlease enter positive numbers for the number of coordinates and clusters\n"
                        + "The number of clusters must be less than the number of coordinates.",
                        "Invalid Entries", JOptionPane.ERROR_MESSAGE);

            }

        } else if (e.getSource() == mResButton && !mRunning) {
            int val = dos(1);
            double nor = 100.0 - (val / 100);
            kMeansAccChart demo = new kMeansAccChart(this, true, (val / 100), nor);
            demo.pack();
            RefineryUtilities.centerFrameOnScreen(demo);
            demo.setVisible(true);
            demo.setDefaultCloseOperation(HIDE_ON_CLOSE);
            if (chk == 0) {
                Ping(6000, 1);
            }
        } else if (e.getSource() == mImplementationCB) {
            boolean b = mImplementationCB.getSelectedItem() == CONCURRENT_KMEANS;
            mThreadCountLabel.setEnabled(b);
            mThreadCountTF.setEnabled(b);
        }
    }

    /**
     * Displays an error dialog stating that insufficient memory is available.
     */
    private void displayInsufficientMemoryDialog() {
        JOptionPane.showMessageDialog(this,
                "Insufficient memory is available.  Try reducing the \n"
                + "number of coordinates and/or the number of clusters.",
                "Insufficient Memory", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Cleanup after completion of k-means.
     */
    public int dos(int k) {
        try {
            // TODO add your handling code here:
            List pr = getRemoveValue(2);
            List<String> items = new CountItemsList<String>();
            Object[] prob = pr.toArray();
            String[] prs = new String[prob.length];
            for (int i = 0; i < prob.length; i++) {
                prs[i] = prob[i].toString();
                System.out.println(i + "" + prob[i].toString());
            }
            BigFile file = new BigFile("input/"+filePath);
            for (String line : file) {
                String[] s = line.split(",");
                items.add(s[2]);
            }

            for (int j = 0; j < prs.length; j++) {
                int prd = ((CountItemsList<String>) items).getCount(prs[j]);
                if (d < prd) {
                    d = prd;
                    ipadd = prs[j].toString();

                }

            }
            if (k == 1) {
                JOptionPane.showMessageDialog(this, ipadd + ": affected Dos");
            } // displayText();
        } catch (Exception ex) {
            // Logger.getLogger(KmeanLoadDataset.class.getName()).log(Level.SEVERE, null, ex);
        }
        return d;
    }

    public void Ping(int pks, int k) {
        try {
            String s = BAsic.pgatt(pks);
            String sv[] = s.split(",");
            int ca = Integer.parseInt(sv[1]);
            dper = "Ping Cluster" + (ca / 100) + "%\n";
            if (k == 1) {
                JOptionPane.showMessageDialog(this, sv[0] + " affected ping of Death");

            }
        } catch (Exception e) {
        }

    }

    public List getRemoveValue(int i) {
        List nodup = null;
        try {
            List li = new ArrayList();
            BigFile file = new BigFile("input/"+filePath);
            for (String line : file) {
                String s[] = line.split(",");

                li.add(s[i]);
            }
            HashSet h = new HashSet(li);
            nodup = new ArrayList(h);

        } catch (Exception ex) {

        }
        return nodup;
    }

    private void cleanupAfterKMeans() {
        if (mKMeans != null) {
            mKMeans.removeKMeansListener(this);
            mKMeans = null;
        }
        mRunning = false;
        mRunButton.setEnabled(true);
    }

    public void kmeansMessage(String message) {
        displayText(message);
    }

    public void kmeansComplete(Cluster[] clusters, long executionTime) {
        displayText("K-Means complete: processing time (ms) = " + executionTime);
        displayText("Number of clusters: " + clusters.length);

        if (chk == 0) {
            displayText(dper);

        } else {
            displayText(pre);
        }
        cleanupAfterKMeans();
    }

    public void kmeansError(Throwable err) {
        cleanupAfterKMeans();
        if (err instanceof InsufficientMemoryException) {
            displayText("K-Means aborted because of insufficient memory.");
            displayInsufficientMemoryDialog();
        } else {
            Throwable t = (Throwable) err;
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            t.printStackTrace(pw);
            displayText(sw.toString());
        }
    }

    private void displayText(String text) {
        mMessageArea.append(text);
        if (!text.endsWith("\n")) {
            mMessageArea.append("\n");
        }
    }

    /**
     * Application entry point.
     *
     * @param args String[]
     */
    public static void start(final int n, String path) {
        filePath = path;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.
                            getSystemLookAndFeelClassName());
                } catch (Exception exception) {
                    exception.printStackTrace();
                }

                KMeansFrame frame = new KMeansFrame(n);
                frame.validate();

                // Center the window
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                Dimension frameSize = frame.getSize();
                if (frameSize.height > screenSize.height) {
                    frameSize.height = screenSize.height;
                }
                if (frameSize.width > screenSize.width) {
                    frameSize.width = screenSize.width;
                }
                frame.setLocation((screenSize.width - frameSize.width) / 2,
                        (screenSize.height - frameSize.height) / 2);
                frame.setVisible(true);
            }
        });
    }

}
