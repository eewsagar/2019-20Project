package com.main.classifiers;

import com.main.features.TextTokenizer;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class NaiveBayes {

    public static String forUpdate = "";

    public static String classifyResult(HashMap<String, String> arrayList) {
//    public static String classifyResult(ArrayList<String> arrayList) {
        int ipositive = 0;
        int inegative = 0;
        int inutral = 0;

        int fpositive = 0;
        int fnegative = 0;
        int fnutral = 0;

        String result = "";

        HashMap<String, ArrayList<String>> trainDataModel = getTrainDataModel();
        ArrayList<String> trainPositive = trainDataModel.get("Positive");
        ArrayList<String> trainNegativ = trainDataModel.get("Negative");
//        for (String string : arrayList) {
        Set<String> keySet = arrayList.keySet();
        for (String string : keySet) {
            String stopword = arrayList.get(string).trim().replaceAll("[-+.^:,]", "") + " . ";
            String preprocess = TextTokenizer.preprocess(stopword);
            String[] split = TextTokenizer.extractKeywords(preprocess);
            int i = 0;
            for (String tokan : split) {
                if (trainPositive.contains(tokan.trim().toLowerCase())) {
                    ipositive++;
                } else if (trainNegativ.contains(tokan.trim().toLowerCase())) {
                    inegative++;
                }
                if (ipositive == 0 && inegative == 0) {
                    inutral++;
                }
                try {
                    if (trainNegativ.contains(tokan.trim().toLowerCase()) && trainNegativ.contains(split[i + 1].trim().toLowerCase())) {
                        ipositive++;
                        inegative = inegative - 2;
                    }
                } catch (Exception e) {
                }
                i++;
            }
            if (ipositive > inegative) {
                fpositive++;
                result = result + "positive\t" + " \t" + ipositive + ":" + split.length + "\t" + inegative + ":" + split.length + "\t=> " + stopword + "\n";
                forUpdate = forUpdate + "positive" + "=" + string + "\n";
//                System.out.println("positive\t" + " p\t" + ipositive + "\tn\t" + inegative + "\t=>\t" + stopword);
            } else if (inegative > 0 && ipositive > 0) {
                result = result + "negative\t" + " \t" + ipositive + ":" + split.length + "\t" + inegative + ":" + split.length + "\t=> " + stopword + "\n";
                forUpdate = forUpdate + "negative" + "= " + string + "\n";
//                System.out.println("negative\t" + " p\t" + ipositive + "\tn\t" + inegative + "\t=>\t" + stopword);
                if (inegative >= ipositive) {
                    fnegative++;
                }
            } else {
                if (ipositive == 0 && inegative == 0) {
                    result = result + "nutral\t" + " \t" + ipositive + ":" + split.length + "\t" + inegative + ":" + split.length + "\t=> " + stopword + "\n";
                    forUpdate = forUpdate + "nutral" + "= " + string + "\n";
                    fnutral++;
                } else {
                    result = result + "negative\t" + " \t" + ipositive + ":" + split.length + "\t" + inegative + ":" + split.length + "\t=> " + stopword + "\n";
                    forUpdate = forUpdate + "negative" + "=  " + string + "\n";
                    fnegative++;
                }
            }
            ipositive = 0;
            inegative = 0;
            inutral = 0;
        }
//        System.out.println("----------------------------------------------------------------------------------");
//        System.out.println("POSITIVE\t=\t" + fpositive);
//        System.out.println("NEGATIVE\t=\t" + fnegative);
//        System.out.println("NUTRAL    \t=\t" + fnutral);
        result = result + "\n----------------------------------------------------------------------------------------------------------------";
        result = result + "\nPOSITIVE\t=\t" + fpositive;
        result = result + "\nNEGATIVE\t=\t" + fnegative;
        result = result + "\nNUTRAL\t=\t" + fnutral;
        result = result + "@ " + fpositive + "-" + fnegative + "-" + fnutral;
        return result;
    }

    /**
     *
     * @return
     */
    public static HashMap<String, ArrayList<String>> getTrainDataModel() {
        ArrayList<String> prositiveList = processForRead("files/positive-words.txt");
        ArrayList<String> negativeList = processForRead("files/negative-words.txt");
        HashMap<String, ArrayList<String>> hashMap = new HashMap<>();
        hashMap.put("Positive", prositiveList);
        hashMap.put("Negative", negativeList);
        return hashMap;
    }

    public static ArrayList<String> processForRead(String path) {
        ArrayList<String> arrayList = new ArrayList<>();
        File file = new File(path);
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bs = new byte[fileInputStream.available()];
            fileInputStream.read(bs);
            String[] split = new String(bs).split(" ");
            for (String string : split) {
                arrayList.add(string.trim().toLowerCase());
            }
        } catch (Exception e) {
        }
        return arrayList;
    }

    public static void main(String[] args) {
        int ipositive = 0;
        int inegative = 0;
        int inutral = 0;

        int fpositive = 0;
        int fnegative = 0;
        int fnutral = 0;

        HashMap<String, ArrayList<String>> trainDataModel = getTrainDataModel();
        ArrayList<String> trainPositive = trainDataModel.get("Positive");
        ArrayList<String> trainNegativ = trainDataModel.get("Negative");

//        String string = "Absorbing and disturbing -- perhaps more disturbing than originally intended -- but a little clarity would have gone a long way";
        String string = "apple is red   not unhappy  ";
        System.out.println("string = " + string);
        String[] split = string.trim().split(" ");
        String last = "";
        int i = 0;
        int rmv = 0;
        for (String tokan : split) {

            if (i < split.length - 1) {
//                System.out.println("next = " + split[i + 1]);
//                if (trainPositive.contains(tokan.trim().toLowerCase()) && trainPositive.contains(split[i + 1].trim().toLowerCase())) {
//                    ipositive++;
//                    System.out.println(tokan + " " + split[i + 1] + "  posi");
//                } else if (trainNegativ.contains(tokan.trim().toLowerCase()) && trainPositive.contains(split[i + 1].trim().toLowerCase())) {
//                    inegative++;
//                    System.out.println(tokan + " " + split[i + 1] + "  nega");
//                } else 
//                    
            }
            if (trainPositive.contains(tokan.trim().toLowerCase())) {
                ipositive++;
            } else if (trainNegativ.contains(tokan.trim().toLowerCase())) {
                inegative++;
            }
            if (trainNegativ.contains(tokan.trim().toLowerCase()) && trainNegativ.contains(split[i + 1].trim().toLowerCase())) {
                ipositive++;
                inegative = inegative - 2;
            }
            i++;
        }
        System.out.println("last = " + last);
        if (ipositive == 0 && inegative == 0) {
            fnutral++;
        }
        if (ipositive > inegative) {
            fpositive++;
        } else {
            fnegative++;
        }
        System.out.println("fnutral = " + fnutral);
        System.out.println("fpositive = " + fpositive);
        System.out.println("fnegative = " + fnegative);
    }
}
