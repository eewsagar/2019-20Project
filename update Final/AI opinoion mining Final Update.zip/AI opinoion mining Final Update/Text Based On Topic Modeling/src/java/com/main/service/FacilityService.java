package com.main.service;

import com.main.dto.FacilityDTO;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Logger;

public class FacilityService {

    public static Integer saveCategory(FacilityDTO dTO) {
        String insertQuery = "INSERT INTO  tbl_facility ("
                + "txtCollegeId,"
                + "facilityname,"
                + " entrydate,"
                + " description, "
                + "`txtIsActive`"
                + ")"
                + "	VALUES ("
                + "'" + dTO.getTxtCollegeName() + "',"
                + "'" + dTO.getFacilityName() + "',"
                + " '" + new Date().toString() + "', "
                + "'" + dTO.getFacilityDescription() + ""
                + "', 'T')\n"
                + "";
        System.out.println("insertQuery = " + insertQuery);
        try {
            MsAccessConnection.preStateMent(insertQuery).execute();
            return 1;
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return null;
    }

    public static Integer updateCategory(FacilityDTO dTO, String id) {
        String updateQuery = "";
        System.out.println("updateQuery = " + updateQuery);

        try {
            MsAccessConnection.preStateMent(updateQuery).execute();

            return 1;
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return null;
    }

    public static ArrayList<FacilityDTO> searchOrListCategory(String id, String mode) {
        String searchQuery = "";
        if (mode.equals("all")) {
            searchQuery = "SELECT * FROM tbl_facility";
        }
        if (mode.equals("search")) {
            searchQuery = "SELECT * FROM tbl_facility WHERE id = '" + id + "'";
        }
        System.out.println("searchQuery = " + searchQuery);
        ArrayList<FacilityDTO> arrayList = new ArrayList<FacilityDTO>();
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(searchQuery).executeQuery();

            while (executeQuery.next()) {
                FacilityDTO dTO = new FacilityDTO();
                dTO.setId(executeQuery.getString("txtId"));
                dTO.setEntryDate(executeQuery.getString("entryDate"));
                dTO.setFacilityName(executeQuery.getString("facilityname"));
                dTO.setFacilityDescription(executeQuery.getString("description"));
                dTO.setIsActive(executeQuery.getString("txtIsActive"));
                arrayList.add(dTO);
            }
            executeQuery.close();
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return arrayList;
    }

    public static Integer postOpinon(FacilityDTO dTO) {
        String insertQuery = "INSERT INTO   `tbl_postopinion` (\n"
                + "`txtStudentId` ,"
                + "`txtPostId` ,"
                + "`facilityname` ,"
                + "`entrydate` ,"
                + "`description` ,"
                + "`txtIsActive`"
                + ") "
                + "VALUES ("
//                + " '"+ +"', "
                + " '1',  "
                + "'name',  "
                + "'date',  "
                + "'description',  "
                + "'Y"
                + ");";
        System.out.println("insertQuery = " + insertQuery);
        try {
            MsAccessConnection.preStateMent(insertQuery).execute();
            return 1;
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return null;
    }

    public static ArrayList<FacilityDTO> searchOrListCollege(String id, String mode) {
        String searchQuery = "";
        if (mode.equals("all")) {
            searchQuery = "SELECT * FROM tbl_college";
        }
        if (mode.equals("search")) {
            searchQuery = "SELECT * FROM tbl_college WHERE id = '" + id + "'";
        }
        System.out.println("searchQuery = " + searchQuery);
        ArrayList<FacilityDTO> arrayList = new ArrayList<FacilityDTO>();
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(searchQuery).executeQuery();

            while (executeQuery.next()) {
                FacilityDTO dTO = new FacilityDTO();
                dTO.setId(executeQuery.getString("txtId"));
                dTO.setEntryDate(executeQuery.getString("entryDate"));
                dTO.setFacilityName(executeQuery.getString("collegename"));
                dTO.setIsActive(executeQuery.getString("txtIsActive"));
                arrayList.add(dTO);
            }
            executeQuery.close();
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return arrayList;
    }
    
    
    
    public static ArrayList<FacilityDTO> searchOrListBranch(String id, String mode) {
        String searchQuery = "";
        if (mode.equals("all")) {
            searchQuery = "SELECT * FROM  tbl_branch";
        }
        if (mode.equals("search")) {
            searchQuery = "SELECT * FROM tbl_branch WHERE id = '" + id + "'";
        }
        System.out.println("searchQuery = " + searchQuery);
        ArrayList<FacilityDTO> arrayList = new ArrayList<FacilityDTO>();
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(searchQuery).executeQuery();

            while (executeQuery.next()) {
                FacilityDTO dTO = new FacilityDTO();
                dTO.setId(executeQuery.getString("txtId"));
                dTO.setEntryDate(executeQuery.getString("entryDate"));
                dTO.setFacilityName(executeQuery.getString("branchname"));
                dTO.setIsActive(executeQuery.getString("txtIsActive"));
                arrayList.add(dTO);
            }
            executeQuery.close();
        } catch (Exception e) {
            Logger.getLogger(FacilityService.class.getName());
        }
        return arrayList;
    }
    
    
    public static void main(String[] args) {
        ArrayList<FacilityDTO> searchOrListCollege = searchOrListCollege("", "all");
        for (FacilityDTO facilityDTO : searchOrListCollege) {
            System.out.println("facilityDTO = " + facilityDTO.getId());
        }
    }
}
