package com.main.view;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Font;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

/**
 * A simple demonstration application showing how to create a pie chart using
 * data from a {@link DefaultPieDataset}.
 */
public class FinalResult extends ApplicationFrame {

    /**
     * Default constructor.
     *
     * @param title the frame title.
     */
    public FinalResult(String title, double pstv, double nega, double ntrl) {
        super(title);
        setContentPane(createDemoPanel(pstv, nega, ntrl));
    }

    /**
     * Creates a sample dataset.
     *
     * @return A sample dataset.
     */
    private static PieDataset createSentimetalDataset(double pst, double neg, double nrt) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Positive", pst);
        dataset.setValue("Negative", neg);
        dataset.setValue("Nutral", nrt);
        return dataset;
    }

    private static JFreeChart createChart(PieDataset dataset) {

        JFreeChart chart = ChartFactory.createPieChart(
                "Sentimental Analysis", // chart title
                dataset, // data
                true, // include legend
                true,
                false
        );

        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
        plot.setNoDataMessage("No data available");
        plot.setCircular(false);
        plot.setLabelGap(0.02);
        return chart;
    }

    /**
     * Creates a panel for the demo (used by SuperDemo.java).
     *
     * @return A panel.
     */
    public static JPanel createDemoPanel(double pstv, double nega, double ntrl) {
//        JFreeChart chart = createChart(createDataset());
//        return new ChartPanel(chart);
        JFreeChart chart = createChart(createSentimetalDataset(pstv, nega, ntrl));
        return new ChartPanel(chart);
    }

}
