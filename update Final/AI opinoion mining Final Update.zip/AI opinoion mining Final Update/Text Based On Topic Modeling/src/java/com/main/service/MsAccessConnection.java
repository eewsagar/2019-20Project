package com.main.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

public class MsAccessConnection {

//    //// line top be modified
    private static final String PORT = "3306";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static Connection connection;
    public static final String URL = "jdbc:mysql://localhost:" + PORT + "/db_aimining";

//// line top be modified server 
//    private static final String PORT = "3306";
//    private static final String USERNAME = "adminjKrLBX8";
//    private static final String PASSWORD = "32bDyhPI79QT";
//    private static final String DATABASE_NAME = "cdsfttm";
//    public static final String URL = "jdbc:mysql://127.10.161.2:3306/"+DATABASE_NAME;
//
//    private static final String DRIVER = "com.mysql.jdbc.Driver";
    static {
        try {
            Class.forName(DRIVER);
            if (connection == null || connection.isClosed()) {
                System.out.println("connect");
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            }
            System.out.println("loaded");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static PreparedStatement preStateMent(String query) {
        try {
            return connection.prepareStatement(query);
        } catch (Exception e) {
            System.out.println("PreparedStatement preStateMent(String query) line number ");
        }
        return null;
    }

    public static String getDate() {
        String[] split = new Date().toString().split(" ");
        String date = "" + split[2] + "-" + split[1] + "-" + split[5];
        System.out.println("date = " + date);
        return date;
    }

    public static void main(String[] args) {
    }

    public static Integer chkUserName(String columnname, String tblName, String value) {
        String sql_query = "SELECT * FROM `" + tblName + "` WHERE `" + columnname + "` = '" + value + "'";
        System.out.println("sql_query = " + sql_query);
        try {
            ResultSet executeQuery = preStateMent(sql_query).executeQuery();
            while (executeQuery.next()) {
                return 1;
            }
            executeQuery.close();;
            return 0;
        } catch (Exception e) {
        }
        return 0;
    }
}
