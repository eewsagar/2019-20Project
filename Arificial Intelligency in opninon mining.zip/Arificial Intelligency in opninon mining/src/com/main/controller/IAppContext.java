package com.main.controller;

public interface IAppContext {

    public void exitApplication();
    public final String TITLE = "Artificial Intelligence for Knowledge Extraction in college Social Networking site";

}
