package eew.main.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class SuperConnection {

    public static Session session = null;
    public static Transaction transaction = null;

    public static boolean checkStatus() {
        try {
            if (session == null) {
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static void saveEntity(Object entity) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        session.save(entity);
        transaction.commit();
        session.close();
    }

    public static void updateEntity(Object entity) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        session.update(entity);
        transaction.commit();
        session.close();
    }

    public static void deleteEntity(Object entity) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        session.delete(entity);
        transaction.commit();
        session.close();
    }

    public static <T> List<T> listEntity(T entity) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        Criteria criteria = session.createCriteria(entity.getClass());
        return criteria.list();
    }

    public static List<Object> listEntityByQuery(String query) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        Query createQuery = session.createQuery(query);
        return createQuery.list();
    }

    public static Object uniqueRecordByQuery(String query) throws Exception {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        Query createQuery = session.createQuery(query);
        return createQuery.uniqueResult();
    }

    public static String getMd5String() {
        String md5 = "" + new Date().getTime();
        StringBuilder sb = new StringBuilder();
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(md5.getBytes());
            byte[] digest = instance.digest();
            for (int index = 0; index < digest.length; index++) {
                sb.append(Integer.toString((digest[index] & 0xff) + 0x100, 16).substring(1));
            }
        } catch (NoSuchAlgorithmException e) {
        }
        return sb.toString();
    }
    
}
