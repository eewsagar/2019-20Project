-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 27, 2015 at 11:34 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_insurance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

drop database if exists MultiCloud;
create database MultiCloud;
use MultiCloud;

CREATE TABLE IF NOT EXISTS `admin` (
  `aname` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aname`, `password`) VALUES
('admin1', 'admin1'),
('test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `collidenode`
--



CREATE TABLE IF NOT EXISTS `login` (
   uid int(11) primary key,
  `name` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mno` varchar(50) DEFAULT NULL
--   `isactive` varchar(1) DEFAULT "Y"
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--


-- --------------------------------------------------------

--
-- Table structure for table `wlogin`
--
 create table if not exists tbl_cloud(
   cid int(11)DEFAULT NULL  primary key,
   cloudid varchar(225)  not null,
   username varchar(225)  not null,
   isactive varchar(1) not null

);
 create table if not exists tbl_download(
   id int(11) not null auto_increment primary key,
   filename varchar(225)  not null,
   block varchar(225)  not null,
   cloudserver varchar(225)  not null,
   isactive varchar(1) not null

);
 create table if not exists tbl_upload(
   id int(11) not null auto_increment primary key,
   filename varchar(225)  not null,
   block varchar(225)  not null,
   cloudserver varchar(225)  not null,
   isactive varchar(1) not null

);

