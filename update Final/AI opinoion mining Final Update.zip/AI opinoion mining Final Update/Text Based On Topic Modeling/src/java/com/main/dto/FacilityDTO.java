package com.main.dto;

public class FacilityDTO {

    public FacilityDTO() {

    }
    private String id;
    private String entryDate;
    private String facilityName;
    private String txtCollegeName;
    private String facilityDescription;
    private String isActive;

    public String getId() {
        return id;
    }

    public String getTxtCollegeName() {
        return txtCollegeName;
    }

    public void setTxtCollegeName(String txtCollegeName) {
        this.txtCollegeName = txtCollegeName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFacilityDescription() {
        return facilityDescription;
    }

    public void setFacilityDescription(String facilityDescription) {
        this.facilityDescription = facilityDescription;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

}
