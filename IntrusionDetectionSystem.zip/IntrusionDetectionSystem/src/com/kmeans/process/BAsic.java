/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kmeans.process;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author star
 */
public class BAsic {

    public static int c = 0;
    public static String avg = "";

    public static String pgatt(int pks) {

        try {
            ArrayList ip = check(pks);
            // System.out.println(ip);
            List ipl = getRemoveValue(ip);
            List<String> items = new CountItemsList<String>();
            Object[] prob = ipl.toArray();
            String[] prs = new String[prob.length];
            for (int i = 0; i < prob.length; i++) {
                prs[i] = prob[i].toString();
                System.out.println(i + "" + prob[i].toString());
            }
            BigFile file = new BigFile("network.csv");
            for (String line : file) {
                String[] s = line.split(",");
                items.add(s[2]);
            }
            for (int j = 0; j < prs.length; j++) {
                int prd = ((CountItemsList<String>) items).getCount(prs[j]);
                if (c < prd) {
                    c = prd;
                    avg = prs[j];
                }
            }

        } catch (Exception ex) {
            Logger.getLogger(BAsic.class.getName()).log(Level.SEVERE, null, ex);
        }
        avg = avg + "," + c;
        return avg;
        // System.out.println(avg+"=="+c);
    }

    public static ArrayList check(int i) {
        ArrayList sv = new ArrayList();
        try {
            BigFile file = new BigFile("network.csv");
            for (String line : file) {
                String[] s = line.split(",");
                int pks = Integer.parseInt(s[4]);
                if (i < pks) {
                    sv.add(s[1]);
                    // System.out.println(sv);
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(BAsic.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sv;
    }

    public static List getRemoveValue(ArrayList l) {
        List nodup = null;
        try {
            List li = l;

            HashSet h = new HashSet(li);
            nodup = new ArrayList(h);

        } catch (Exception ex) {

        }
        return nodup;
    }

}
