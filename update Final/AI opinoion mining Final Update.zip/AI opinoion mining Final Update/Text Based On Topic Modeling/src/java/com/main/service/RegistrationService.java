package com.main.service;

import com.main.dto.ProductDTO;
import com.main.dto.UserDTO;
import java.util.logging.Logger;

public class RegistrationService {

    public static Integer saveStudent(UserDTO dTO) {
        String insertQuery = "INSERT INTO `tbl_student` ("
                + " `firstname`,"
                + " `lastname`, "
                + "`contact`, "
                + "`email`, "
                + "`toyear`, "
                + "`branch`, "
                + "`username`, "
                + "`password`, "
                + "`entrydate`, "
                + "`txtIsActive`"
                + ") VALUES ("
                + "'" + dTO.getFirstname() + "', "
                + "'" + dTO.getLastname() + "', "
                + "'" + dTO.getContact() + "', "
                + "'" + dTO.getEmail() + "', "
                + "'" + dTO.getToyear() + "', "
                + "'" + dTO.getBranch() + "', "
                + "'" + dTO.getUsername() + "', "
                + "'" + dTO.getPassword() + "', "
                + "'" + MsAccessConnection.getDate() + "', "
                + "'T');";
       
        System.out.println("insertQuery = " + insertQuery);
        try {
            MsAccessConnection.preStateMent(insertQuery).execute();
            return 1;
        } catch (Exception e) {
            Logger.getLogger(RegistrationService.class.getName());
        }
        return null;
    }

    public static Integer saveTeacher(ProductDTO dTO) {
        String insertQuery = "INSERT INTO  `tbl_student` (`txtId`, `firstname`, `lastname`, `contact`, `email`, `toyear`, `branch`, `username`, `password`, `entrydate`, `txtIsActive`) VALUES (NULL, 'fullname', 'lastname', 'contact', 'email', 'toytear', 'branch', 'username', 'password', '2014-03-19', 't');";
        try {
            MsAccessConnection.preStateMent(insertQuery).execute();

            return 1;
        } catch (Exception e) {
            Logger.getLogger(RegistrationService.class.getName());
        }
        return null;
    }

    public static void main(String[] args) {
    }
}
