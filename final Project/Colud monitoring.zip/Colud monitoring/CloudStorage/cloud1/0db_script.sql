DROP DATABASE IF EXISTS publicauditability;
CREATE DATABASE publicauditability;
USE publicauditability;

