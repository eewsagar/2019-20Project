DROP DATABASE IF EXISTS db_aimining;
CREATE DATABASE db_aimining;
USE db_aimining;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_openion`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_branch`
--

CREATE TABLE IF NOT EXISTS `tbl_branch` (
  `txtId` int(11) NOT NULL,
  `branchname` varchar(100) DEFAULT NULL,
  `entrydate` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_branch`
--

INSERT INTO `tbl_branch` (`txtId`, `branchname`, `entrydate`, `txtIsActive`) VALUES
(1, 'INFORMAION TECHNOLOGIES', 'FRI APR 11 21:48:58 IST 2014', 'Y'),
(2, 'COMPUTER SCIENCES ', 'FRI APR 11 21:49:06 IST 2014', 'Y'),
(3, 'ELECTRONICS AND COMMUNICATION  ', 'FRI APR 11 21:49:12 IST 2014', 'Y'),
(4, 'MECHANICAL ENGINEER  ', 'FRI APR 11 21:49:12 IST 2014', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_college`
--

CREATE TABLE IF NOT EXISTS `tbl_college` (
  `txtId` int(11) NOT NULL,
  `collegename` varchar(100) DEFAULT NULL,
  `entrydate` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_college`
--

INSERT INTO `tbl_college` (`txtId`, `collegename`, `entrydate`, `txtIsActive`) VALUES
(1, 'PUSAD COLLEGE ', 'FRI APR 11 21:48:58 IST 2014', 'Y'),
(2, 'BHAGAWATI COLLEGE', 'FRI APR 11 21:49:06 IST 2014', 'Y'),
(3, 'YCCE COLLEGE', 'FRI APR 11 21:49:12 IST 2014', 'Y'),
(4, 'DY PATIL COLLEGE', 'FRI APR 11 21:49:12 IST 2014', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `txtId` int(11) NOT NULL,
  `pve` int(2) NOT NULL,
  `nve` int(2) NOT NULL,
  `ntrl` int(2) NOT NULL,
  `facilityId` varchar(60) DEFAULT NULL,
  `txtBrachId` varchar(60) NOT NULL,
  `txtCollegeId` varchar(60) NOT NULL,
  `studentId` int(11) DEFAULT NULL,
  `description` text,
  `image` text,
  `entrydate` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_comment`
--

CREATE TABLE IF NOT EXISTS `tbl_facility` (
  `txtId` int(11) NOT NULL AUTO_INCREMENT primary key,
  `facilityname` varchar(100) DEFAULT NULL,
  `txtCollegeId` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `entrydate` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment_split`
--

CREATE TABLE IF NOT EXISTS `tbl_comment_split` (
  `txtId` int(11) NOT NULL,
  `facilityId` varchar(60) DEFAULT NULL,
  `txtCollegeId` varchar(60) NOT NULL,
  `studentId` int(11) DEFAULT NULL,
  `description` text,
  `entrydate` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `txtId` int(11) NOT NULL,
  `firstname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `entrydate` varchar(200) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_postimage`
--

CREATE TABLE IF NOT EXISTS `tbl_postimage` (
  `txtId` int(11) NOT NULL,
  `txtCollegeName` varchar(60) NOT NULL,
  `txtDescription` varchar(60) NOT NULL,
  `imgfile` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_result`
--

CREATE TABLE IF NOT EXISTS `tbl_result` (
  `txtId` int(11) NOT NULL,
  `clgname` varchar(500) DEFAULT NULL,
  `faciname` varchar(200) DEFAULT NULL,
  `positive` varchar(10) DEFAULT NULL,
  `negative` varchar(10) DEFAULT NULL,
  `nutral` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE IF NOT EXISTS `tbl_student` (
  `txtId` int(11) NOT NULL,
  `firstname` varchar(200) DEFAULT NULL,
  `lastname` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `toyear` varchar(200) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `entrydate` varchar(500) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

-- INSERT INTO `tbl_student` (`txtId`, `firstname`, `lastname`, `contact`, `email`, `toyear`, `branch`, `username`, `password`, `entrydate`, `txtIsActive`) VALUES
-- (3, 'Pravin ', 'Tumsare', '7416363492', 'pravin@gmail.com', 'I YEAR', 'COMPUTER SCIENCES', 'pravintumsare', 'james@007', '08-Feb-2016', 'T'),
-- (4, 'Pravin ', 'Tumsare', '7416363492', 'ptumsare@gmail.com', 'I YEAR', 'COMPUTER SCIENCES', 'ptumsare@gmail.com', 'james@007', '04-Mar-2016', 'T');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_training`
--

CREATE TABLE IF NOT EXISTS `tbl_training` (
  `txtId` int(11) NOT NULL,
  `lable` varchar(100) DEFAULT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `txtIsActive` char(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_training`
--

INSERT INTO `tbl_training` (`txtId`, `lable`, `keyword`, `txtIsActive`) VALUES
(1, '', 'food', 'y'),
(2, '', 'menu', 'y'),
(3, '', 'hygenic', 'y'),
(4, '', 'kitchen', 'y'),
(5, '', 'eatables', 'y'),
(6, '', 'food', 'y'),
(7, '', 'coffee', 'y'),
(8, '', 'tea', 'y'),
(9, '', 'lunch', 'y'),
(10, '', 'restaurant', 'y'),
(11, '', 'menu card', 'y'),
(12, '', 'canteen', 'y'),
(13, '', '', 'y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_college`
--
ALTER TABLE `tbl_college`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_comment_split`
--
ALTER TABLE `tbl_comment_split`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_postimage`
--
ALTER TABLE `tbl_postimage`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_result`
--
ALTER TABLE `tbl_result`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`txtId`);

--
-- Indexes for table `tbl_training`
--
ALTER TABLE `tbl_training`
  ADD PRIMARY KEY (`txtId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_college`
--
ALTER TABLE `tbl_college`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_comment_split`
--
ALTER TABLE `tbl_comment_split`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_postimage`
--
ALTER TABLE `tbl_postimage`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_result`
--
ALTER TABLE `tbl_result`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_student`
--
ALTER TABLE `tbl_student`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_training`
--
ALTER TABLE `tbl_training`
  MODIFY `txtId` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
