/*
 * Copyright (C) 2014 yuvraj
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package com.main.features;

import com.main.controller.MsAccessConnection;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author yuvraj
 */
public class MakeDataSet {

    public static void main(String[] args) {
        String createTrainingSet = createTrainingSet();
        String createdataSet = getDataSet();
        System.out.println("createTrainingSet = " + createTrainingSet);
        System.out.println("createdataSet = " + createdataSet);
    }

    public static String getFullDataset() {
        String createTrainingSet = createTrainingSet();
        System.out.println("createTrainingSet = " + createTrainingSet);
        return "";
    }

    public static ArrayList<String> getTraningSet() {
        ArrayList<String> arrayList = new ArrayList<String>();
        String sqlsearch = "SELECT DISTINCT  `lable` FROM  `tbl_training` ";
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(sqlsearch).executeQuery();
            while (executeQuery.next()) {
                arrayList.add(executeQuery.getString("lable").trim().toLowerCase());
            }
            executeQuery.close();
        } catch (Exception e) {
        }
        return arrayList;
    }

    public static String getKeywordSet(String string) {
        String keyword = "";
        String sqlsearch = "SELECT DISTINCT  keyword \n"
                + "FROM  `tbl_training` \n"
                + "WHERE  `lable` LIKE  '%" + string.toLowerCase() + "%'";
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(sqlsearch).executeQuery();
            while (executeQuery.next()) {
                String string1 = executeQuery.getString("keyword");
                if (string1.trim().length() != 0) {
                    keyword = keyword + string1.trim().replaceAll("\n", "") + ",";
                }
            }
            executeQuery.close();
        } catch (Exception e) {
        }
        return keyword;
    }

    public static String createTrainingSet() {
        String set = "";
        for (String string : getTraningSet()) {
            String keywordSet = getKeywordSet(string);
            set = set + "@attribute " + string.toLowerCase() + " { " + keywordSet + "  }\n";
        }
        return set;
    }

    public static String getDataSet() {
        String keyword = "";
        String sqlsearch = "SELECT description \n"
                + "FROM  `tbl_comment` \n";
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(sqlsearch).executeQuery();
            while (executeQuery.next()) {
                String string1 = executeQuery.getString("description");
                keyword = keyword + string1.trim().replaceAll(" ", ",") + "\n";
            }
            executeQuery.close();
        } catch (Exception e) {
        }
        return "@data\n"+keyword;
    }
}
