archar(50) DEFAULT NULL,
  `CloudServer` varchar(50) DEFAULT NULL,
  `Keys` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

