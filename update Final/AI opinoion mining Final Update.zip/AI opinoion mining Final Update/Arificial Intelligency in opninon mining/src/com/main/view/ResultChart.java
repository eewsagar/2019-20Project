package com.main.view;

import java.awt.Font;
import java.io.File;
import java.io.IOException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

public class ResultChart {

    public void createTimeSeriesXYChart(double a, double b, double c) {

        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("POSITIVE" + a, new Double(a));
        dataset.setValue("NEGATIVE " + b, new Double(b));
        dataset.setValue("NUTRAL" + c, new Double(c));
        JFreeChart chart = ChartFactory.createPieChart(
                "MINE OPINION", // chart title
                dataset, // data
                true, // include legend
                true,
                false);

        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
        plot.setNoDataMessage("No data available");
        plot.setCircular(false);
        plot.setLabelGap(0.02);
        saveChart(chart);

    }

    public void saveChart(JFreeChart chart) {
        String fileName = "src/com/main/result/result.jpg";
        try {
            ChartUtilities.saveChartAsJPEG(new File(fileName), chart, 800, 600);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Problem occurred creating chart.");
        }
    }

    public static void main(String args[]) {
        new ResultChart().createTimeSeriesXYChart(2.3, 3.3, 5.5);
    }
}
