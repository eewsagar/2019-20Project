
 
package download;

 
public class Download {

    public static void main(String[] args) {
        try {
            Client.receiveFile(1);
            Client.receiveFile(2);
        } catch (Exception e) {
            System.out.println("e = " + e.getMessage());
        }
    }
}
