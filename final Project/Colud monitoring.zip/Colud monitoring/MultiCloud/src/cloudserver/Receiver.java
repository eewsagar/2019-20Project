/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cloudserver;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;

/**
 *
 * @author seabirds
 */
public class Receiver extends Thread {

    MainFrame mf;
    Details dt = new Details();

    Receiver(MainFrame me) {
        mf = me;

    }

    public void run() {
        try {
            DatagramSocket ds = new DatagramSocket(9000);
            while (true) {
                byte data[] = new byte[10000];
                DatagramPacket dp = new DatagramPacket(data, 0, data.length);
                ds.receive(dp);
                String str = new String(dp.getData()).trim();
                String req[] = str.split("#");

                if (req[0].equals("CloudDt")) {
                    DefaultTableModel dm1 = (DefaultTableModel) mf.jTable1.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    dm1.addRow(v);

                    dt.cloud[dt.cind][0] = Integer.parseInt(req[1]); // id
                    dt.cloud[dt.cind][1] = Integer.parseInt(req[2]); // pt 
                    dt.cind++;

                } // cloud dt

                if (req[0].equals("UserDt")) {
                    DefaultTableModel dm1 = (DefaultTableModel) mf.jTable2.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    dm1.addRow(v);

                    dt.user[dt.uind][0] = req[1]; // id
                    dt.user[dt.uind][1] = req[2]; // name
                    dt.user[dt.uind][2] = req[3]; //pt
                    dt.uind++;

                } // user dt

                if (req[0].equals("GetCS")) {
                    String g1 = "CSInfo";
                    for (int i = 0; i < dt.cind; i++) {
                        g1 = g1 + "#" + dt.cloud[i][0];
                    }
                    int pt = Integer.parseInt(req[3]);
                    System.out.println(g1 + " : " + pt);
                    byte bt[] = g1.getBytes();
                    DatagramPacket dp1 = new DatagramPacket(bt, 0, bt.length, InetAddress.getByName("localhost"), pt);
                    ds.send(dp1);
                    System.out.println("send to " + pt);

                } // getcs

                if (req[0].equals("UploadFile")) {
                    DefaultTableModel dm1 = (DefaultTableModel) mf.jTable3.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    v.add(req[3]);
                    v.add(req[4]);
                    dm1.addRow(v);

                } // upload file

                if (req[0].equals("DownloadFile")) {
                    DefaultTableModel dm1 = (DefaultTableModel) mf.jTable3.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    v.add(req[3]);
                    v.add(req[4]);
                    dm1.addRow(v);

                } // download

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
