package com.main.process;

import java.io.File;
import java.io.FileInputStream;

public class Process {

    public static void main(String[] args) {
        try {
            File file = new File("files/negative-words.txt");
            System.out.println("file = " + file.isDirectory());
            FileInputStream fileInputStream = new FileInputStream(file);
            int available = fileInputStream.available();
            byte[] bs = new byte[available];
            fileInputStream.read(bs);
            fileInputStream.close();
            String string = new String(bs);
            String[] split = string.split("\n");
            for (String string1 : split) {
                System.out.print(string1 + " ");
            }
        } catch (Exception e) {
        }
    }
}
