package download;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 */
public interface IAppContext {

    public String CLIENT_IPADDRESS = "192.168.174.1";
//    public String CLIENT_IPADDRESS = "127.0.0.1";

}
