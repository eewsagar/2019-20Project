/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cloudserver;

/**
 *
 * @author seabirds
 */
public class Details {

    static int cloud[][] = new int[10][2];
    static int cind = 0;

    static String user[][] = new String[10][3];
    static int uind = 0;
}
