package com.main.model;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type;
import java.util.ArrayList;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataListener;
 
public class CollegeComboModel implements ComboBoxModel {

    private ArrayList<String> collegeList;
    private String string;

    public CollegeComboModel() {
    }

    public CollegeComboModel(ArrayList<String> collegeList) {
        this.collegeList = collegeList;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        string = (String) anItem;
    }

    @Override
    public Object getSelectedItem() {
        return string;
    }

    @Override
    public int getSize() {
        return collegeList.size();
    }

    @Override
    public Object getElementAt(int index) {
        return collegeList.get(index);
    }

    @Override
    public void addListDataListener(ListDataListener l) {
    }

    @Override
    public void removeListDataListener(ListDataListener l) {
    }

}
