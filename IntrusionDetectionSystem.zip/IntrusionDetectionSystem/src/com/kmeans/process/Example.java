/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.kmeans.process;

/**
 *
 * @author star
 */
public class Example {
  public static  void start()
    {
      IPAddressFormatValidator ipva=new IPAddressFormatValidator();

        try {
             
            BigFileRead file = new BigFileRead("network.csv");
            for(String line:file)
            {
               String s[]=line.split(",");
              
               if(s[1]!=null && s[1].equalsIgnoreCase("")==false)
               {
                   int fdx=s[1].indexOf("/");


                   if(fdx>1)
                   {

                       String srcip=s[1].substring(0, fdx);

                       boolean res= ipva.validate(srcip);
                        System.out.println(res+"=="+srcip);
                   }else
                   {
                        String srcip=s[1].replaceAll("/", "");
                        boolean res=ipva.validate(srcip);
                         System.out.println(res+"=="+srcip);
                   }

                }
            }
        } catch (Exception ex) {
          //  Logger.getLogger(IPAddressFormatValidator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
