/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cloudstorage;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import javax.swing.JOptionPane;
import javax.swing.JFrame;

/**
 *
 * @author seabirds
 */
public class CloudReceiver extends Thread {

    CloudFrame cf;
    int cid;
    int cpt;
    String path;
    DatagramSocket ds;

    CloudReceiver(CloudFrame ce, int id) {
        cf = ce;
        cid = id;
        cpt = cid + 8000;
    }

    public void run() {
        try {
            File fe = new File("cloud" + cid);
            fe.mkdir();
            path = fe.getPath();

            try {
                ds = new DatagramSocket(cpt);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(new JFrame(), "Id already exist");
                System.exit(0);
            }

            String sg = "CloudDt#" + cid + "#" + cpt;
            byte dt[] = sg.getBytes();
            DatagramPacket dpt1 = new DatagramPacket(dt, 0, dt.length, InetAddress.getByName("localhost"), 9000);
            ds.send(dpt1);
            while (true) {
                byte data[] = new byte[10000];
                DatagramPacket dp = new DatagramPacket(data, 0, data.length);
                ds.receive(dp);
                String str = new String(dp.getData()).trim();
                String req[] = str.split("#");

                if (req[0].equals("Upload")) {
                    DefaultTableModel dm1 = (DefaultTableModel) cf.jTable1.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    v.add(req[3]);

                    dm1.addRow(v);

                    String fn = req[3] + req[2];
                    File f1 = new File(path + "\\" + fn);
                    FileOutputStream fos = new FileOutputStream(f1);
                    fos.write(req[4].getBytes());
                    fos.close();

                } // upload

                if (req[0].equals("Download")) {
                    DefaultTableModel dm1 = (DefaultTableModel) cf.jTable2.getModel();
                    Vector v = new Vector();
                    v.add(req[1]);
                    v.add(req[2]);
                    v.add(req[3]);

                    dm1.addRow(v);

                    String pp = req[3] + req[2];
                    File f1 = new File(path + "\\" + pp);
                    FileInputStream fis = new FileInputStream(f1);
                    byte bt[] = new byte[fis.available()];
                    fis.read(bt);
                    fis.close();

                    String cc = new String(bt);
                    int pt = Integer.parseInt(req[1]) + 7000;
                    String ms = "down#" + cc;
                    byte be[] = ms.getBytes();
                    DatagramPacket dpt = new DatagramPacket(be, 0, be.length, InetAddress.getByName("localhost"), pt);
                    ds.send(dpt);

                } // download

                if (req[0].equals("Verify")) {
                    String uid = req[1]; // id
                    String g1 = req[2];  // fn
                    String g2 = req[3];  // ind1
                    String ch = req[4];  // check
                    String g3 = g2 + g1;

                    File f1 = new File(path + "\\" + g3);
                    FileInputStream fis = new FileInputStream(f1);
                    byte dat[] = new byte[fis.available()];
                    fis.read(dat);
                    fis.close();

                    String sg1 = new String(dat);
                    String c1 = String.valueOf(sg1.charAt(0));
                    c1 = c1 + String.valueOf(sg1.charAt(sg1.length() / 2));
                    c1 = c1 + String.valueOf(sg1.charAt(sg1.length() - 1));
                    System.out.println("c1 " + c1 + " : " + ch);
                    String res = "VerifyRes#";
                    if (c1.equals(ch)) {
                        res = res + "Ok";
                    } else {
                        res = res + "No";
                    }

                    int pt = Integer.parseInt(uid) + 7000;
                    byte be[] = res.getBytes();
                    DatagramPacket dpt2 = new DatagramPacket(be, 0, be.length, InetAddress.getByName("localhost"), pt);
                    ds.send(dpt2);

                } // verify

                if (req[0].equals("GetContent")) {
                    String uid = req[1]; // id
                    String g1 = req[2];  // fn
                    String g2 = req[3];  // ind1
                    String ch = req[4];  // check
                    String g3 = g2 + g1;

                    File f1 = new File(path + "\\" + g3);
                    FileInputStream fis = new FileInputStream(f1);
                    byte dat[] = new byte[fis.available()];
                    fis.read(dat);
                    fis.close();

                    String sg1 = new String(dat);
                    String msg = "SetContent#" + g1 + "#" + g2 + "#" + sg1;
                    int pt = Integer.parseInt(uid) + 7000;
                    byte be[] = msg.getBytes();
                    DatagramPacket dpt2 = new DatagramPacket(be, 0, be.length, InetAddress.getByName("localhost"), pt);
                    ds.send(dpt2);
                } // getcontent

                if (req[0].equals("Operation")) {
                    String g1 = req[1];  // fn
                    String g2 = req[2];  // ind1

                    String g3 = g2 + g1;

                    File f1 = new File(path + "\\" + g3);
                    FileOutputStream fos = new FileOutputStream(f1);
                    fos.write(req[3].getBytes());
                    fos.close();

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
