/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.servlet;

import com.main.service.MsAccessConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author yuvraj
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String txtFullName = request.getParameter("txtUserName");
            String txtPassword = request.getParameter("txtPassword");
            
            String login = "SELECT  *  FROM  `tbl_student`  WHERE  `username` =  '" + txtFullName + "' AND  `password` =  '" + txtPassword + "'";
            System.out.println("login = " + login);
            String loginId = "";
            String type = "";
            String email = "";
            String fullname = "";
            try {
                ResultSet executeQuery = MsAccessConnection.preStateMent(login).executeQuery();
                while (executeQuery.next()) {
                    loginId = executeQuery.getString("txtId");
                    email = executeQuery.getString("email");
                    fullname = executeQuery.getString("firstname")+" "+ executeQuery.getString("lastname");
                }
            } catch (Exception e) {
            }
            out.print(loginId);
            if (!loginId.equals("")) {
                request.getSession().setAttribute("username", loginId);
                request.getSession().setAttribute("email", email);
                request.getSession().setAttribute("fullname", fullname);
                request.getSession().setAttribute("id", loginId);
                response.sendRedirect("index.jsp");
            } else {
                response.sendRedirect("index.jsp?page=postopinion");
            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
