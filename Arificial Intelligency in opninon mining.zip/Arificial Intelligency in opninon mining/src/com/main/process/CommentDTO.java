package com.main.process;

/**
 *
 * @author yuvraj
 */
public class CommentDTO {

    private String txtCollegeId;
    private String facilityId;
    private String description;

    public String getTxtCollegeId() {
        return txtCollegeId;
    }

    public void setTxtCollegeId(String txtCollegeId) {
        this.txtCollegeId = txtCollegeId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
