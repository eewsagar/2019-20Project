package download;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class Client {

    public static void receiveFile(int counter) {
        try {
            int filesize = 1022386;
            int bytesRead;
            int currentTot = 0;
            Socket socket = new Socket(IAppContext.CLIENT_IPADDRESS, counter);
            System.out.println("CLIENT PORT NUMBER :- " + counter);
            byte[] bytearray = new byte[filesize];
            InputStream is = socket.getInputStream();
            String extension = "";
            if (counter == 1) {
                extension = "tesing.txt";
            } else {
                extension = "classes.arff";
            }
            FileOutputStream fos = new FileOutputStream("input/" + extension);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            bytesRead = is.read(bytearray, 0, bytearray.length);
            currentTot = bytesRead;
            do {
                bytesRead = is.read(bytearray, currentTot, (bytearray.length - currentTot));
                if (bytesRead >= 0) {
                    currentTot += bytesRead;
                }
            } while (bytesRead > -1);
            bos.write(bytearray, 0, currentTot);
            bos.flush();
            bos.close();
            socket.close();
        } catch (Exception e) {
            System.out.println("e = " + e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException {
        for (int index = 1; index < 5; index++) {
            receiveFile(index);
        }
    }

}
