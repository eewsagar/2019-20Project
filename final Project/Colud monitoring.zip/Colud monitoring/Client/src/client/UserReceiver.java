/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author seabirds
 */
public class UserReceiver extends Thread {

    UserFrame uf;
    int uid;
    int upt;
    String uname;

    UserReceiver(UserFrame ue, String s1, String s2) {
        uf = ue;
        uid = Integer.parseInt(s1);
        upt = uid + 7000;
        uname = s2;
    }

    public void run() {
        try {
            //   System.out.println("comes in ");
            DatagramSocket ds = new DatagramSocket(upt);

            String sg = "UserDt#" + uid + "#" + uname + "#" + upt;
            byte dt[] = sg.getBytes();
            DatagramPacket dpt1 = new DatagramPacket(dt, 0, dt.length, InetAddress.getByName("localhost"), 9000);
            ds.send(dpt1);

            while (true) {
                byte data[] = new byte[10000];
                DatagramPacket dp = new DatagramPacket(data, 0, data.length);
                ds.receive(dp);
                String str = new String(dp.getData()).trim();
                String req[] = str.split("#");

                if (req[0].equals("CSInfo")) {

                    uf.jList1.removeAll();
                    Vector v = new Vector();
                    for (int i = 1; i < req.length; i++) {
                        v.add(req[i]);
                    }
                    uf.jList1.setListData(v);
                    System.out.println(v);

                } // csinfo

                if (req[0].equals("down")) {
                    String g = req[1];
                    String txt = uf.txtDFileData.getText().trim();
                    txt = txt + g;
                    uf.txtDFileData.setText(txt);

                } //down

                if (req[0].equals("VerifyRes")) {
                    if (req[1].equals("Ok")) {
                        JOptionPane.showMessageDialog(uf, "File is verified");
                    } else {
                        JOptionPane.showMessageDialog(uf, "content is changed");
                    }
                } // verify res

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
