/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.refector;

/**
 *
 * @author piyush
 */
public interface ITableSetting {

    final static Class STRINGCLASS = String.class;
    //********Table Column Name*******//
    final static String COLUMN_SRNO = "SR NO";
    final static String COLUMN_CODE_NO = "Code No";
    final static String COLUMN_DATE = "Date";
    final static String COLUMN_TIME = "Time";
    final static String COLUMN_F_NAME = "First Name";
    final static String COLUMN_L_NAME = "Last Name";
    final static String COLUMN_FULL_NAME = "Full Name";
    final static String COLUMN_ADDRESS = "Address";
    final static String COLUMN_LEVEL = "Level";
    final static String COLUMN_CONTACT = "Mobile No";
    final static String COLUMN_PAIDAMT = "Paid Amount";
    final static String COLUMN_EMAIL = "Email";
    final static String COLUMN_ACTION = "Action";
    final static String COLUMN_USERNAME = "User Name";
    final static String COLUMN_PASSWORD = "Password";
    final static String COLUMN_BALANCE_AMNT = "BalanceAmount";
    final static String COLUMN_CODENUMBER = "Code No";
    final static String COLUMN_CURRENTAMOUNT = "Amount";
    final static String COLUMN_PAIDDATE = "Paid Date";
    final static String COLUMN_BALANCEAMT = "Balance Amount";
    //********
    //  Table Column Name Width
    //        *******//
    final static int COLUMN_WIDTH_SRNO = 45;
    final static int COLUMN_WIDTH_COLUMN_CODE_NO = 45;
    final static int COLUMN_WIDTH_LEVEL = 80;
    final static int COLUMN_WIDTH_DATE = 70;
    final static int COLUMN_WIDTH_TIME = 70;
    final static int COLUMN_WIDTH_F_NAME = 100;
    final static int COLUMN_WIDTH_L_NAME = 100;
    final static int COLUMN_WIDTH_FULL_NAME = 300;
    final static int COLUMN_WIDTH_CONTACT = 120;
    final static int COLUMN_WIDTH_EMAIL = 120;
    final static int COLUMN_WIDTH_USERNAME = 90;
    final static int COLUMN_WIDTH_PASSWORD = 90;
    final static int COLUMN_WIDTH_BALANCE_AMNT = 120;
    final static int COLUMN_WIDTH_PAIDAMT = 120;
    final static int COLUMN_WIDTH_CODENUMBER = 150;
    final static int COLUMN_WIDTH_CURRENTAMOUNT = 100;
}
