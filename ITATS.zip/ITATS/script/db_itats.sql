-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2017 at 07:54 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_itats`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataentry`
--

CREATE TABLE IF NOT EXISTS `dataentry` (
  `id` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `nmae` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `charge` varchar(30) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dataentry`
--

INSERT INTO `dataentry` (`id`, `category`, `type`, `nmae`, `city`, `address`, `charge`) VALUES
(1, 'Tour', 'Hills Station', 'JAMSAVALI', 'NAGPUR', 'SHREE SHREE HANUMAN TEMPLE SAONER', '400'),
(2, 'Tour', 'Zoo', 'MAHARAJ BHAG', 'NAGPUR', 'NEAR SITABULDI NAGPUR', '50'),
(3, 'Tour', 'Temple', 'shree gajanan maharaj', 'NAGPUR', 'shree gajanan maharaj temple', '80'),
(4, 'Transpotation', 'Railway', 'duranto', 'NAGPUR', '', '600'),
(5, 'Transpotation', 'Bus', 'saini travelles', 'NAGPUR', '', '240'),
(6, 'Transpotation', 'Rikhsha', 'juganu', 'NAGPUR', '', '320'),
(7, 'Transpotation', 'Auto', 'zataka', 'NAGPUR', '', '350'),
(8, 'Hotel', 'hotel pride', '2 Star', 'NAGPUR', 'wardha road ', '1200'),
(9, 'Hotel', 'sun and sand', '3 Star', 'NAGPUR', 'near great nag road', '600'),
(10, 'Food', 'Maharastrian', 'pintu saoji', 'NAGPUR', 'near kalimata temple ', '550'),
(11, 'Food', 'Thali', 'sapana hotel', 'NAGPUR', 'near suprim quote', '600'),
(12, 'Transaction', 'ATM', 'bank of badoda', 'NAGPUR', 'near man mohan', 'N/A'),
(13, 'Hotel', 'Redison', '3 Star', 'Nagpur', 'Wardha Road', '500'),
(14, 'Hotel', '3 Star', 'Redison', 'Nagpur', 'Wardha Road', '500');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE IF NOT EXISTS `tbl_registration` (
  `id` int(11) NOT NULL,
  `txtUserType` varchar(30) DEFAULT NULL,
  `txtFirstName` varchar(30) DEFAULT NULL,
  `txtMobileNumber` varchar(30) DEFAULT NULL,
  `txtEmailId` varchar(30) DEFAULT NULL,
  `txtUserName` varchar(30) DEFAULT NULL,
  `txtPassword` varchar(30) DEFAULT NULL,
  `txtEntryDate` varchar(30) DEFAULT NULL,
  `txtIsActive` varchar(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`id`, `txtUserType`, `txtFirstName`, `txtMobileNumber`, `txtEmailId`, `txtUserName`, `txtPassword`, `txtEntryDate`, `txtIsActive`) VALUES
(1, 'admin', 'sagar', '7620572224', 'eew.sagar@gmail.com', 'eew.sagar@gmail.com', '1232456', '28/02/2017', 'Y'),
(2, 'd', 'pravin tumsare', '7416363492', 'pravintumsare@gmail.com', 'pravintumsare@gmail.com', '123456', NULL, 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataentry`
--
ALTER TABLE `dataentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataentry`
--
ALTER TABLE `dataentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
