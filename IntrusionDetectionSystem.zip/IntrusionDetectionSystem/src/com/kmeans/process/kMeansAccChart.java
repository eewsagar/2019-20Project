/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kmeans.process;

/**
 *
 * @author star
 */
import java.awt.Font;
import javax.swing.JDialog;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class kMeansAccChart extends JDialog {

    public kMeansAccChart(java.awt.Frame parent, boolean modal, double tot, double free) {
        super(parent, modal);
        setContentPane(createDemoPanel(tot, free));

    }

    private static PieDataset createDataset(double tot, double free) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Attack", tot);
        dataset.setValue("Normal", free);

        return dataset;
    }

    private static JFreeChart createChart(PieDataset dataset) {

        JFreeChart chart = ChartFactory.createPieChart(
                " Chart ", // chart title
                dataset, // data
                true, // include legend
                true,
                false
        );

        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelFont(new Font("SansSerif", Font.PLAIN, 12));
        plot.setNoDataMessage("No data available");
        plot.setCircular(false);
        plot.setLabelGap(0.02);
        return chart;

    }

    public static JPanel createDemoPanel(double tot, double free) {
        JFreeChart chart = createChart(createDataset(tot, free));
        return new ChartPanel(chart);
    }

}
