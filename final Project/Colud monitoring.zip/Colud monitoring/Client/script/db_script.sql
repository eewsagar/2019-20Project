DROP DATABASE IF EXISTS publicauditability;
CREATE DATABASE publicauditability;
USE publicauditability;

# Dumping structure for table publicauditability.login
--  + uid + "','" + name + "','" + pass + "','" + email + "','" + mno +
CREATE TABLE IF NOT EXISTS `login` (
  `uid` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mno` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table publicauditability.login: ~0 rows (approximately)
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`uid`, `name`, `pass`, `email`, `mno`) VALUES
	('1', 'rani', 'rani', 'rani@gmail.com', '1234');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


# Dumping structure for table publicauditability.upload
CREATE TABLE IF NOT EXISTS `upload` (
  `UId` varchar(50) DEFAULT NULL,
  `FileName` varchar(50) DEFAULT NULL,
  `blocks` varchar(50) DEFAULT NULL,
  `CloudServer` varchar(50) DEFAULT NULL,
  `Keys` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table publicauditability.upload: ~0 rows (approximately)
/*!40000 ALTER TABLE `upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
