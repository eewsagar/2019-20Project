package com.main.dto;

public class OptimizeDTO implements Comparable<OptimizeDTO> {

    private FoodDTO foodDTO;
    private HotelDTO hotelDTO;
    private TourDTO tourDTO;
    private TransportDTO transportDTO;
    private String charges;

    public String getCharges() {
        return charges;
    }

    public void setCharges(String charges) {
        this.charges = charges;
    }

    public FoodDTO getFoodDTO() {
        return foodDTO;
    }

    public void setFoodDTO(FoodDTO foodDTO) {
        this.foodDTO = foodDTO;
    }

    public HotelDTO getHotelDTO() {
        return hotelDTO;
    }

    public void setHotelDTO(HotelDTO hotelDTO) {
        this.hotelDTO = hotelDTO;
    }

    public TourDTO getTourDTO() {
        return tourDTO;
    }

    public void setTourDTO(TourDTO tourDTO) {
        this.tourDTO = tourDTO;
    }

    public TransportDTO getTransportDTO() {
        return transportDTO;
    }

    public void setTransportDTO(TransportDTO transportDTO) {
        this.transportDTO = transportDTO;
    }

    @Override
    public int compareTo(OptimizeDTO o) {
        int comparePrice = Integer.parseInt(((OptimizeDTO) o).getCharges());
        return Integer.parseInt(this.charges) - comparePrice;
    }

}
