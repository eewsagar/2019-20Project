package com.main.service;

import com.main.controller.MsAccessConnection;
import java.sql.ResultSet;
import java.util.ArrayList;

public class LookUpService {

    public static ArrayList<String> getCollegeName() {
        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            String query = "SELECT collegename FROM `tbl_college`";
            ResultSet execute = MsAccessConnection.preStateMent(query).executeQuery();
            while (execute.next()) {
                String string = execute.getString("collegename");
                arrayList.add(string);
            }
        } catch (Exception e) {
        }
        return arrayList;
    }

    public static void main(String[] args) {
        ArrayList<String> collegeName = getCollegeName();
        System.out.println("collegeName = " + collegeName.size());
        for (String string : collegeName) {
            System.out.println("string = " + string);
        }
    }
    
}
