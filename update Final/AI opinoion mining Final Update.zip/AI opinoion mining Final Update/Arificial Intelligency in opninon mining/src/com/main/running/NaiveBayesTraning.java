package com.main.running;

import com.main.classifiers.NaiveBayes;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NaiveBayesTraning {

    public static String[] readLines(URL url) throws IOException {

        Reader fileReader = new InputStreamReader(url.openStream(), Charset.forName("UTF-8"));
        List<String> lines;
        try (BufferedReader bufferedReader = new BufferedReader(fileReader)) {
            lines = new ArrayList<>();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines.toArray(new String[lines.size()]);
    }

    public static void trainModel() throws IOException {
        //map of dataset files
        Map<String, URL> trainingFiles = new HashMap<>();
        trainingFiles.put("Positive", NaiveBayesTraning.class.getResource("/datasets/positive-words.txt"));
        trainingFiles.put("Negative", NaiveBayesTraning.class.getResource("/datasets/negative-words.txt"));

        //loading examples in memory
        Map<String, String[]> trainingExamples = new HashMap<>();
        for (Map.Entry<String, URL> entry : trainingFiles.entrySet()) {
            trainingExamples.put(entry.getKey(), readLines(entry.getValue()));
        }

        //train classifier
        NaiveBayes nb = new NaiveBayes();
        NaiveBayes.getTrainDataModel();
//        nb.train(trainingExamples);
    }

    public static void main(String[] args) {
        try {
            trainModel();
        } catch (Exception e) {
        }
    }
}
