/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kmeans.process;

/**
 *
 * @author star
 */
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IPAddressFormatValidator {

    public Pattern pattern;
    public Matcher matcher;

    private static String IPADDRESS_PATTERN
            = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
            + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

    public IPAddressFormatValidator() {
        pattern = Pattern.compile(IPADDRESS_PATTERN);
    }

    /**
     * Validate ip address with regular expression
     *
     * @param ip ip address for validation
     * @return true valid ip address, false invalid ip address
     */
    public boolean validate(String ip) throws NullPointerException {
        System.out.println(ip);
        matcher = pattern.matcher(ip);
        return matcher.matches();
    }

}
