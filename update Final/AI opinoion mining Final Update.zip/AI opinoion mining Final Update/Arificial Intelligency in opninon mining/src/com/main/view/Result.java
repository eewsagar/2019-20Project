package com.main.view;

import com.main.classifiers.NaiveBayes;
import com.main.controller.IAppContext;
import com.main.controller.MsAccessConnection;
import com.main.model.CollegeComboModel;
import com.main.refector.IConstantManager;
import com.main.service.LookUpService;
import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.ui.RefineryUtilities;

public class Result extends javax.swing.JFrame {

    HashMap<String, String> hashMap;

    public Result() {
        initComponents();
        setTitle(IAppContext.TITLE);
        loadCollege();
    }

    Result(HashMap<String, String> hashMap) {
        initComponents();
        setTitle(IAppContext.TITLE);
        this.hashMap = hashMap;
        loadCollege();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));

        jButton1.setForeground(new java.awt.Color(0, 0, 102));
        jButton1.setText("SHOW RESULT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jComboBox1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel3.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.BorderLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/main/images/images (8).jpg"))); // NOI18N
        jPanel2.add(jLabel1, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 854, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
            String toString = jComboBox1.getSelectedItem().toString();
            if (toString != null) {
                HashMap<String, String> hashMap = searchByCollege(toString);
                String classifyResult = NaiveBayes.classifyResult(hashMap);
                String[] split = classifyResult.split("@");
                jTextArea1.setText(split[0]);
//            makedataset();
                String counter[] = split[1].split("-");
                String string = NaiveBayes.forUpdate;
                System.out.println("string = " + string);
                try {
                    updateComment(string);
                } catch (Exception e) {
                    System.out.println("e = " + e.getMessage());
                }
                FinalResult finalResult = new FinalResult(IConstantManager.TITLE, Double.parseDouble(counter[0]), Double.parseDouble(counter[1]), Double.parseDouble(counter[2]));
                finalResult.pack();
                RefineryUtilities.centerFrameOnScreen(finalResult);
                finalResult.setVisible(true);
            }
        } catch (Exception e) {
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Result().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables

//    private void makedataset() {
//        try {
//
//            String trim = jTextArea1.getText().trim().split("\n\n")[0];
//            String filecontain = "@relation opinion.symbolic\n"
//                    + "\n"
//                    + "@attribute opinion{ positive,negative,nutral}\n"
//                    + "\n"
//                    + "@data\n\n";
//            String data = "";
//            for (String string : trim.split("\n")) {
//                data = data + string.split(" ")[0].toLowerCase() + "\n";
//            }
//            String contain = filecontain + data;
//            File file = new File("wekadataset/" + System.currentTimeMillis() + ".arff");
//            FileWriter fileWriter = new FileWriter(file);
//            fileWriter.write(contain);
//            fileWriter.close();
//        } catch (Exception e) {
//        }
//    }
//
    private void updateComment(String forUpdate) {
        String toWrite = "";
        String[] split = forUpdate.split("\n");
        for (String string : split) {
            try {
                String[] splitComment = string.split("=");

                System.out.println("splitComment = " + splitComment[0]);
                System.out.println("splitComment = " + splitComment[1]);

                String result = splitComment[0];
                String txtId = splitComment[1];
                toWrite = toWrite + " " + result;
                String update = "UPDATE  `tbl_comment` SET `facilityId` = '" + result + "' WHERE  `txtId` =  " + txtId;
                System.out.println("update = " + update);
                MsAccessConnection.preStateMent(update).execute();
            } catch (SQLException ex) {
                Logger.getLogger(Result.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        writeToFile(toWrite);
    }

    private void loadCollege() {
        jComboBox1.setModel(new CollegeComboModel(LookUpService.getCollegeName()));
    }

    private HashMap<String, String> searchByCollege(String toString) {
        HashMap<String, String> hashMap = new HashMap<>();
        String query = "SELECT * FROM `tbl_comment` WHERE `txtCollegeId` LIKE '%" + toString + "%'";
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(query).executeQuery();
            while (executeQuery.next()) {
                String txtId = executeQuery.getString("txtId");
                String description = executeQuery.getString("description");
                hashMap.put(txtId, description);
            }
        } catch (Exception e) {
        }
        return hashMap;
    }

    private void writeToFile(String string) {
        try {
            File file = new File("hadoop/hadoopipnut.txt");
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(string);
            fileWriter.close();
        } catch (Exception e) {
            e.getMessage();
        }
    }

}
